package utility;

public class Validation {
}
