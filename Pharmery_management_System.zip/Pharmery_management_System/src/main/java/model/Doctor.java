package model;

public class Doctor {
    public Doctor() {
    }
}
